const games = [
  {
    name: 'Watch Dogs 2', platform: 'PS4 / PS5', type: 'owned', label: 'JOC CUMPĂRAT', note: 'Sesiune activă acum', logo: '/assets/watch-dogs-2.jpg', logoClass: 'cover-art', status: 'PLAYING', statusDetail: 'RIGHT NOW'
  },
  {
    name: 'Roblox', platform: 'PS4 / PS5', type: 'owned', label: 'JOC CUMPĂRAT', note: 'În biblioteca mea', logo: '/assets/roblox-user-banner.jpg', logoClass: 'cover-art', status: 'OWNED', statusDetail: 'LOCAL LIBRARY'
  },
  {
    name: 'EA SPORTS FC 27', platform: 'PS4 / PS5', type: 'owned', label: 'CEL MAI NOU FIFA', note: 'În biblioteca mea', logo: '/assets/ea-sports-fc-27-user-edited.png', logoClass: 'cover-art', status: 'OWNED', statusDetail: 'LOCAL LIBRARY'
  },
  {
    name: 'GTA V', platform: 'PS4 / PS5', type: 'owned', label: 'JOC CUMPĂRAT', note: 'În biblioteca mea', logo: '/assets/gta-v-instant-gaming-cover.jpg', logoClass: 'cover-art', status: 'OWNED', statusDetail: 'LOCAL LIBRARY'
  },
  {
    name: 'GTA VI', platform: 'PS5', type: 'waiting', label: 'PRE-ORDER ACHIZIȚIONAT', note: 'Aștept ediția PS5 cu GTA VI', logo: '/assets/gta-vi-banner.jpg', logoClass: 'cover-art', status: 'WAITING', statusDetail: 'COMING SOON'
  }
];

const list = document.querySelector('#library-list');
const count = document.querySelector('#visible-count');
const platformMarkup = (platform) => platform.includes('PS4') && platform.includes('PS5')
  ? '<span class="mini-platforms"><b class="ps4-text">PS4</b><em>/</em><b class="ps5-text">PS5</b></span>'
  : '<span class="mini-platforms"><b class="ps5-text">PS5</b></span>';

function renderGames(filter = 'all') {
  const filtered = games.filter((game) => filter === 'all' || game.type === filter);
  count.textContent = String(filtered.length).padStart(2, '0');
  list.innerHTML = filtered.map((game, index) => `
    <article class="library-item game-library-card ${game.type === 'waiting' ? 'is-waiting' : ''}" data-type="${game.type}">
      <div class="game-logo-frame ${game.logoClass}"><img src="${game.logo}" alt="Logo ${game.name}" loading="lazy" /></div>
      <div class="game-card-content">
        <div class="game-card-top"><span class="item-number">${String(index + 1).padStart(2, '0')}</span><span class="item-title">${game.name}</span></div>
        <div class="game-card-label">${game.label}</div>
        <div class="item-meta">${platformMarkup(game.platform)} <span>•</span> ${game.note}</div>
      </div>
      <div class="game-card-status ${game.type === 'waiting' ? 'waiting' : ''}"><span class="status-dot"></span>${game.status}<small>${game.statusDetail}</small></div>
    </article>
  `).join('');
}

document.querySelectorAll('.filter-button').forEach((button) => {
  button.addEventListener('click', () => {
    document.querySelectorAll('.filter-button').forEach((item) => item.classList.remove('is-active'));
    button.classList.add('is-active');
    renderGames(button.dataset.filter);
  });
});

document.querySelector('#focus-library').addEventListener('click', () => {
  document.querySelector('#library').scrollIntoView({ behavior: 'smooth' });
});

const matrix = document.querySelector('#matrix-field');
const glyphs = '01ABCDEF<>[]{}()$#@%&/\\';
for (let index = 0; index < 28; index += 1) {
  const column = document.createElement('span');
  column.className = 'matrix-column';
  column.style.left = `${(index * 3.8) + Math.random() * 2}%`;
  column.style.animationDuration = `${8 + Math.random() * 12}s`;
  column.style.animationDelay = `${Math.random() * -16}s`;
  column.textContent = Array.from({ length: 32 }, () => glyphs[Math.floor(Math.random() * glyphs.length)]).join('');
  matrix.appendChild(column);
}

renderGames();

const siteAudio = document.querySelector('#site-audio');
if (siteAudio) {
  siteAudio.volume = 0.7;
  const soundGate = document.querySelector('#sound-gate');
  const enableSound = document.querySelector('#enable-sound');
  const soundToggle = document.querySelector('#sound-toggle');
  const attemptPlayback = () => {
    siteAudio.play().catch(() => {
      // Chrome and other browsers may block autoplay with sound until interaction.
    });
  };
  attemptPlayback();
  enableSound.addEventListener('click', async () => {
    try {
      await siteAudio.play();
      soundGate.classList.add('is-hidden');
      window.setTimeout(() => { soundGate.hidden = true; }, 350);
      soundToggle.hidden = false;
    } catch {
      enableSound.querySelector('span').textContent = 'Încearcă din nou';
    }
  });
  soundToggle.addEventListener('click', () => {
    if (siteAudio.paused) {
      siteAudio.play();
      soundToggle.textContent = '♫ Muzică pornită';
      soundToggle.setAttribute('aria-label', 'Oprește muzica');
    } else {
      siteAudio.pause();
      soundToggle.textContent = '♫ Pornește muzica';
      soundToggle.setAttribute('aria-label', 'Pornește muzica');
    }
  });
}
